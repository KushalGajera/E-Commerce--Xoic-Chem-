import React from 'react'
import { Link } from 'react-router-dom'

import { IoChatbubbles } from "react-icons/io5";
import { IoCallSharp } from "react-icons/io5";
import { IoMail } from "react-icons/io5";
import { FaFacebook, FaInstagram } from 'react-icons/fa';
import { FaXTwitter } from "react-icons/fa6";
import { RiWhatsappFill } from "react-icons/ri";

import { SiPhonepe } from "react-icons/si";
import { FaGooglePay } from "react-icons/fa";
import { SiPaytm } from "react-icons/si";
import { FaCcVisa } from "react-icons/fa6";
import { FaCcMastercard } from "react-icons/fa";



import logo from '../assets/logo.png';
import { Button, Tooltip } from '@mui/material';

export const Footer = () => {
    return (
        <>
            <footer className="bg-gray-900 text-white py-10">
                <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">

                    {/* Company Info */}
                    <div>
                        <h2 className="font-bold mb-4 items-center justify-center ">
                            <img src={logo} className='h-[80px] w-[80px] transition-transform duration-300 hover:scale-110 drop-shadow-lg' alt="Company Logo" />
                        </h2>
                        <p className="text-gray-300 leading-relaxed text-sm tracking-wide">Your one-stop shop for everything you need. Discover deals and shop smart!</p>

                        <hr />
                        <h5 className='pt-10 !text-amber-200'>Payment Option</h5>
                        <div className="flex items-center gap-4 pt-2 md:mb-0">
                            <Tooltip title="Phone Pe">
                            <SiPhonepe className="h-[24px] w-[24px] transition-transform duration-300 hover:scale-110 hover:text-blue-600" />
                            </Tooltip>
                            <Tooltip title="Google Pay">
                            <FaGooglePay className="h-[24px] w-[24px] transition-transform duration-300 hover:scale-110 hover:text-yellow-300" />
                            </Tooltip>
                            <Tooltip title="Paytm">
                            <SiPaytm className="h-[24px] w-[24px] transition-transform duration-300 hover:scale-110 hover:text-blue-300" />
                            </Tooltip>
                            <Tooltip title="Visa Card">
                            <FaCcVisa className="h-[24px] w-[24px] transition-transform duration-300 hover:scale-110 hover:text-blue-400" />
                            </Tooltip>
                            <Tooltip title="Master Card">
                            <FaCcMastercard className="h-[24px] w-[24px] transition-transform duration-300 hover:scale-110 hover:text-red-300" />
                            </Tooltip>
                        </div>
                    </div>

                    {/* Navigation Links */}
                    <div>
                        <h3 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Quick Links</h3>
                        <ul className="space-y-2">
                            <li><Link className="link1 hover:text-[#7fc119] hover:underline transition duration-300">Home</Link></li>
                            <li><Link className="link1 hover:text-[#7fc119] hover:underline transition duration-300">Products</Link></li>
                            <li><Link className="link1 hover:text-[#7fc119] hover:underline transition duration-300">About Us</Link></li>
                            <li><Link className="link1 hover:text-[#7fc119] hover:underline transition duration-300">Contact</Link></li>
                            <li><Link className="link1 hover:text-[#7fc119] hover:underline transition duration-300">Serivces</Link></li>
                        </ul>
                    </div>

                    {/* Contact Info */}
                    <div>
                        <h3 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Contact Us</h3>

                        <Link to='mailto:xoicchem@gmail.com' className='link1 block hover:text-[#7fc119] transition duration-300'>
                            <span className="flex items-center gap-3 py-1">
                                <IoMail className="text-[#7fc119] text-xl" />
                                <span className='text-sm'>xoicchem@gmail.com</span>
                            </span>
                        </Link>

                        <Link to='tel:+919510512938' className='link1 block hover:text-[#7fc119] transition duration-300 mt-1'>
                            <span className="flex items-center gap-3 py-1">
                                <IoCallSharp className="text-[#7fc119] text-xl" />
                                <span> +91 95105 12938</span>
                            </span>
                        </Link>

                        <p className='link1 mt-1 text-gray-300'>
                            <span className="flex items-center gap-3 py-1">
                                <IoChatbubbles className="text-[#7fc119] text-xl" />
                                <span> 10, Mota Varachha, Surat</span>
                            </span>
                        </p>

                        <div className="mt-4 overflow-hidden rounded-xl shadow-md border border-gray-700 hover:shadow-xl transition-shadow duration-300">
                            <iframe
                                title="Company Location"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3718.765633512825!2d72.86945987344133!3d21.241140280453674!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f3706ffca93%3A0x44e477c918d4e154!2sXOIC%20Chemicals!5e0!3m2!1sen!2sin!4v1748361751980!5m2!1sen!2sin"
                                width="100%"
                                height="150"
                                allowFullScreen=""
                                loading="lazy"
                                className="rounded-lg border-0"
                            ></iframe>
                        </div>
                    </div>

                    {/* Social Icons */}
                    <div>
                        <h3 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">Follow Us</h3>
                        <div className="flex text-[#7fc119] space-x-4 text-2xl mb-4">
                            <Link href="#" className="hover:!text-blue-500 !text-white transition duration-300 hover:scale-110"><FaFacebook /></Link>
                            <Link href="#" className="hover:!text-sky-400 !text-white transition duration-300 hover:scale-110"><FaXTwitter /></Link>
                            <Link href="#" className="hover:!text-pink-500 !text-white transition duration-300 hover:scale-110"><FaInstagram /></Link>
                            <Link href="#" className="hover:!text-green-500 !text-white transition duration-300 hover:scale-110"><RiWhatsappFill /></Link>
                        </div>

                        <form className="flex flex-col sm:flex-row gap-2">
                            <input
                                type="email"
                                placeholder="Enter your email"
                                className="w-full px-3 py-2 rounded-md bg-white text-black focus:outline-none focus:ring-2 focus:ring-[#7fc119] transition duration-300 shadow-sm"
                            />
                            <Button
                                type=""
                                className="!bg-[#7fc119] hover:!bg-green-600 px-4 py-2 !rounded-md text-black font-semibold transition duration-300 shadow-md hover:!shadow-lg"
                            >
                                Subscribe
                            </Button>
                        </form>
                    </div>
                </div>

                <div className="text-center mt-10 border-t border-gray-700 pt-4 text-sm text-gray-400">
                    &copy; {new Date().getFullYear()} <span className='text-[#7fc119] cursor-pointer'> XoicChem. </span> All rights reserved.
                </div>
            </footer>
        </>
    )
}
