import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import '../compontes/css/Homecat.css';
import { Navigation, Autoplay } from 'swiper/modules';
import { Link } from 'react-router-dom';

// Product images
import pro1 from '../assets/products/pro2.jpg';
import pro2 from '../assets/products/pro1.jpg';
import pro3 from '../assets/products/pro3.jpg';
import pro4 from '../assets/products/pro4.jpg';
import pro5 from '../assets/products/pro5.jpg';
import pro6 from '../assets/products/pro6.jpg';
import pro7 from '../assets/products/pro7.jpg';
import pro8 from '../assets/products/pro8.jpg';
import pro9 from '../assets/products/pro9.jpg';
import pro10 from '../assets/products/pro10.jpg';
import pro11 from '../assets/products/pro11.jpg';
import pro12 from '../assets/products/pro12.jpg';

export const HomeCatSlider = () => {
    const products = [
        { img: pro1, name: "Powder" },
        { img: pro2, name: "Liquid" },
        { img: pro3, name: "Soap" },
        { img: pro4, name: "Wiper" },
        { img: pro5, name: "Solar Wiper" },
        { img: pro6, name: "Shaampoo" },
        { img: pro7, name: "Cleaner" },
        { img: pro8, name: "Solar Brush" },
        { img: pro9, name: "Brush" },
        { img: pro10, name: "Liquid Phenyl" },
        { img: pro11, name: "Naphthalene" },
        { img: pro12, name: "Dishwasher" },
    ];

    return (
        <div className="container pt-3 pb-4">
            <Swiper
                navigation={true}
                slidesPerView={5}
                spaceBetween={27}
                autoplay={{
                    delay: 20000,
                    disableOnInteraction: false,
                }}
                modules={[Navigation, Autoplay]}
                className="mySwiper1 pt-3 px-2"
            >
                {products.map((product, index) => (
                    <SwiperSlide className="cat1 flex flex-col min-w-[90px] px-1" key={index}>
                        <Link to="/" className="link1 flex flex-col items-center no-underline w-full">
                            <div className="image-container w-20 h-20 overflow-hidden rounded-lg md:w-36 md:h-36 shadow-md">
                                <img
                                    src={product.img}
                                    alt={product.name}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                            <p className="pt-3 text-black text-xs md:text-lg truncate w-full text-center">
                                {product.name}
                            </p>
                        </Link>
                    </SwiperSlide>

                ))}
            </Swiper>
        </div>
    );
};
