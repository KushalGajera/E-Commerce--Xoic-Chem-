import React, { useState } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';


import banner1 from '../assets/products/banner1.jpg'
import banner2 from '../assets/products/banner2.jpg'
import banner3 from '../assets/products/banner3.jpg'
import { Listproductslider } from './Listproductslider';



export const Listslider = () => {

    const productData = {
        Liquid: [],
        Powder: [],
        Brush: [],
        Plastic: [],
        Tab: [],
        Doal: [],
        Savarna: [],
        Dori: []
    };

    const tabLabels = Object.keys(productData);
    const [value, setValue] = useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };



    return (
        <>
            {/* list slider section */}
            <section className="bg-white py-8">
                <div className="container mx-auto px-4 flex flex-col md:flex-row items-start gap-8">
                    {/* Left */}
                    <div className="md:w-1/4">
                        <div className="space-y-2">
                            <h5 className="text-2xl font-bold text-gray-900">Popular Products:</h5>
                            <p className="text-sm text-gray-500">Don't miss this sale of the season!</p>
                        </div>

                        {/* left banner */}
                        <div className="banner py-1 flex-col md:flex-row gap-4">
                            <div className="banner1 pt-1 transition-transform duration-500 ease-in-out transform hover:scale-105">
                                <img src={banner1} alt="Banner 1" className="rounded-lg shadow-md" />
                            </div>
                            <div className="banner1 pt-5 transition-transform duration-500 ease-in-out transform hover:scale-105">
                                <img src={banner2} alt="Banner 2" className="rounded-lg shadow-md" />
                            </div>
                            <div className="banner1 pt-5 transition-transform duration-500 ease-in-out transform hover:scale-105">
                                <img src={banner3} alt="Banner 2" className="rounded-lg shadow-md" />
                            </div>
                        </div>
                    </div>

                    {/* Tabs and Products */}
                    <div className="md:w-3/4 w-full">
                        <Box sx={{ maxWidth: '100%' }}>
                            <Tabs
                                value={value}
                                onChange={handleChange}
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="popular products tabs"
                                textColor="primary"
                                indicatorColor="primary"
                                sx={{
                                    '& .MuiTab-root': {
                                        fontWeight: 500,
                                        textTransform: 'none',
                                        paddingX: 2,
                                        transition: 'all 0.3s ease',
                                        '&:hover': {
                                            bgcolor: 'rgba(0, 0, 0, 0.04)',
                                            borderRadius: '8px',
                                            color: '#5e990e',
                                        },
                                    }, '& .Mui-selected': {
                                        color: '#5e990e !important',
                                    },
                                    '& .MuiTabs-indicator': {
                                        backgroundColor: '#7fc119',
                                        textColor: '#7fc119',
                                        height: 3,
                                        borderRadius: 2,
                                    },
                                }}
                            >
                                {tabLabels.map((label) => (
                                    <Tab key={label} label={label} />
                                ))}
                            </Tabs>
                        </Box>


                        <Listproductslider />
                    </div>
                </div>
            </section>
        </>
    )
}
