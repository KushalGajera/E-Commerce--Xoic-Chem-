import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/navigation';

import './css/style.css';

import slider1 from '../assets/slider1.jpg';
import slider2 from '../assets/slider2.jpg';
import slider3 from '../assets/slider3.jpg';

import { Navigation, Autoplay } from 'swiper/modules';

export const HomeSlider = () => {
    return (
        <div className="homeslider bg-gray-100 py-4">
            <div className="container-fuild max-w-screen-xl mx-auto px-4">
                <Swiper
                    navigation={true}
                    autoplay={{
                        delay: 10000,
                        disableOnInteraction: false,
                    }}
                    modules={[Navigation, Autoplay]}
                    className="mySwiper rounded-2xl shadow-lg overflow-hidden"
                >
                    <SwiperSlide>
                        <img
                            src={slider1}
                            alt="Home slider"
                            className="w-full h-[200px] sm:h-[300px] md:h-[400px] lg:h-[500px] object-cover transition-all duration-500 ease-in-out"
                        />
                    </SwiperSlide>
                    <SwiperSlide>
                        <img
                            src={slider2}
                            alt="Home slider"
                            className="w-full h-[200px] sm:h-[300px] md:h-[400px] lg:h-[500px] object-cover transition-all duration-500 ease-in-out"
                        />
                    </SwiperSlide>
                    <SwiperSlide>
                        <img
                            src={slider3}
                            alt="Home slider"
                            className="w-full h-[200px] sm:h-[300px] md:h-[400px] lg:h-[500px] object-cover transition-all duration-500 ease-in-out"
                        />
                    </SwiperSlide>
                </Swiper>
            </div>
        </div>
    );
};
