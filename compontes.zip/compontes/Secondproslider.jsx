import React from 'react';
import { HiMiniShoppingBag } from 'react-icons/hi2';
import { IoEyeSharp } from 'react-icons/io5';
import { IoMdHeart } from 'react-icons/io';
import pro1 from '../assets/products/bg-1.png';
import pro2 from '../assets/products/bg-2.png';
import { Link } from 'react-router-dom';

// Correct product list with varying data
const products = [
    {
        id: 1,
        title: 'Glass Cleaner',
        price: '$89.99',
        rating: '★★★★☆',
        reviews: '(42)',
        image: pro1,
    },
    {
        id: 2,
        title: 'Window Cleaner',
        price: '$79.99',
        rating: '★★★☆☆',
        reviews: '(20)',
        image: pro2,
    },
    {
        id: 3,
        title: 'Car Shampoo',
        price: '$59.99',
        rating: '★★★★★',
        reviews: '(105)',
        image: pro1,
    },
    {
        id: 4,
        title: 'Wax Polish',
        price: '$49.99',
        rating: '★★★★☆',
        reviews: '(89)',
        image: pro2,
    },
    {
        id: 5,
        title: 'Tire Shine',
        price: '$29.99',
        rating: '★★★☆☆',
        reviews: '(60)',
        image: pro1,
    },
    {
        id: 6,
        title: 'Interior Cleaner',
        price: '$69.99',
        rating: '★★★★☆',
        reviews: '(35)',
        image: pro2,
    },
    {
        id: 7,
        title: 'Engine Degreaser',
        price: '$99.99',
        rating: '★★★★★',
        reviews: '(75)',
        image: pro1,
    },
    {
        id: 8,
        title: 'Dashboard Polish',
        price: '$39.99',
        rating: '★★★☆☆',
        reviews: '(18)',
        image: pro2,
    },
];

export const Secondproslider = () => {
    return (
        <section className="bg-gray-100">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 p-6 bg-gray-100">
                {products.map((product, index) => (
                    <div
                        key={index}
                        className="relative bg-white rounded-3xl shadow-md overflow-hidden p-4 group transition-all duration-500 hover:shadow-2xl hover:scale-[1.02] hover:border-blue-500 border border-transparent"
                    >
                        {/* Hover Action Icons */}
                        <div className="absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 z-20">
                            <button
                                title="Add to Wishlist"
                                className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                            >
                                <IoMdHeart className="text-[#7fc119] w-5 h-5" />
                            </button>
                            <button
                                title="Quick View"
                                className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                            >
                                <IoEyeSharp className="text-[#7fc119] w-5 h-5" />
                            </button>
                        </div>

                        {/* Image */}
                        <div className="flex items-center justify-center my-6 overflow-hidden rounded-xl">
                            <Link to={`/product/${product.id}`}>
                                <img
                                    src={product.image}
                                    alt="Product"
                                    className="h-40 object-contain transition-transform duration-500 ease-in-out group-hover:scale-110"
                                />
                            </Link>
                        </div>

                        {/* Product Details */}
                        <div className="transition-opacity duration-500 ease-in-out group-hover:opacity-100 opacity-95">
                            <h3 className="text-center text-base font-semibold text-gray-800 mb-2">
                                {product.title}
                            </h3>
                            <div className="text-center text-lg font-bold text-gray-900 mb-1">
                                {product.price}
                            </div>
                            <div className="flex justify-center items-center text-yellow-400 text-sm mb-4">
                                {product.rating}
                                <span className="ml-2 text-gray-500">{product.reviews}</span>
                            </div>

                            {/* Add to Cart */}
                            <button className="w-full bg-[#7fc119] text-white py-2 px-4 !rounded-xl flex items-center justify-center gap-2 hover:bg-[#8fc125] hover:scale-[1.02] active:scale-100 transition-all duration-300 shadow-md hover:shadow-lg">
                                <HiMiniShoppingBag className="w-5 h-5" />
                                Add to Cart
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
};
