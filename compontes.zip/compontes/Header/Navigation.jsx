import React, { useState } from 'react';
import Button from '@mui/material/Button';
import { HiOutlineMenuAlt2 } from 'react-icons/hi';
import { Link } from 'react-router-dom';
import { FaHome, FaBoxOpen } from 'react-icons/fa';
import { MdMiscellaneousServices, MdLocalPhone } from 'react-icons/md';
import { BsExclamationLg } from 'react-icons/bs';
import { PiNewspaperFill } from 'react-icons/pi';
import { Categoriespanel } from './Categoriespanel';

export const Navigation = () => {
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleMouseEnter = () => {
    setIsProductsOpen(true);
  };

  const handleMouseLeave = () => {
    setIsProductsOpen(false);
  };

  const menuItems = (
    <>
      <li className="list-none pt-2.5 font-semibold">
        <Link to='/' className='link1 transition flex gap-2'>
          <FaHome className='pt-1.5 h-[20px] w-[20px]' />
          Home
        </Link>
      </li>

      {/* Products menu */}
      <li
        className="list-none pt-2.5 font-semibold relative"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className='link1 transition flex gap-1 items-center cursor-pointer'>
          <Link to='/ProductList' className='link1 transition flex gap-2'>
            <FaBoxOpen className='pt-1.5 h-[20px] w-[20px]' />
            Products
          </Link>
        </div>

        <div className={`submenu absolute top-[100%] left-0 min-w-[200px] bg-white shadow-md z-50 transition-all duration-300 py-2 ${isProductsOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2 pointer-events-none'}`}>
          <ul className='nav1'>
            <li className='list-none'>
              <Button className='w-full h-[50px] !text-left !justify-start !rounded-none px-4'>
                <Link
                  to="/ProductList?category=Liquid"
                  className='text-black link1 hover:!text-[#7fc119] !capitalize !text-[15px] transition py-[7%] w-full'
                >
                  Liquid
                </Link>
              </Button>
            </li>
            <li className='list-none'>
              <Button className='w-full h-[50px] !text-left !justify-start !rounded-none px-4'>
                <Link
                  to="/ProductList?category=Powder"
                  className='text-black link1 hover:!text-[#7fc119] !capitalize !text-[15px] transition py-[7%] w-full'
                >
                  Powder
                </Link>
              </Button>
            </li>
            <li className='list-none'>
              <Button className='w-full h-[50px] !text-left !justify-start !rounded-none px-4'>
                <Link
                  to="/ProductList?category=Soap"
                  className='text-black link1 hover:!text-[#7fc119] !capitalize !text-[15px] transition py-[7%] w-full'
                >
                  Soap
                </Link>
              </Button>
            </li>
            <li className='list-none'>
              <Button className='w-full h-[50px] !text-left !justify-start !rounded-none px-4'>
                <Link
                  to="/ProductList?category=Solar"
                  className='text-black link1 hover:!text-[#7fc119] !capitalize !text-[15px] transition py-[7%] w-full'
                >
                  Solar
                </Link>
              </Button>
            </li>
            <li className='list-none'>
              <Button className='w-full h-[50px] !text-left !justify-start !rounded-none px-4'>
                <Link
                  to="/ProductList?category=Plastic"
                  className='text-black link1 hover:!text-[#7fc119] !capitalize !text-[15px] transition py-[7%] w-full'
                >
                  Plastic
                </Link>
              </Button>
            </li>
          </ul>
        </div>
      </li>

      <li className="list-none pt-2.5 font-semibold">
        <Link to='/Services' className='link1 transition flex gap-1'>
          <MdMiscellaneousServices className='pt-1.5 h-[20px] w-[20px]' />
          Services
        </Link>
      </li>

      <li className="list-none pt-2.5 font-semibold">
        <Link to='/About' className='link1 transition flex gap-1'>
          <BsExclamationLg className='pt-1.5 h-[20px] w-[20px]' />
          About Us
        </Link>
      </li>

      <li className="list-none pt-2.5 font-semibold">
        <Link to='/Contact' className='link1 transition flex gap-1'>
          <MdLocalPhone className='pt-1.5 h-[20px] w-[20px]' />
          Contact
        </Link>
      </li>

      <li className="list-none pt-2.5 font-semibold">
        <Link to='/Blog' className='link1 transition flex gap-1'>
          <PiNewspaperFill className='pt-1.5 h-[20px] w-[20px]' />
          Blog & News
        </Link>
      </li>
    </>
  );

  return (
    <nav>
      <div className="container flex items-center justify-between px-4 py-3">
        {/* Hamburger for mobile */}
        <div className="md:hidden">
          <button onClick={toggleMobileMenu}>
            <HiOutlineMenuAlt2 className="text-3xl" />
          </button>
        </div>

        {/* Categories Panel - visible on desktop */}
        <div className="hidden md:flex w-[20%]">
          <Categoriespanel />
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex w-[80%] ml-auto">
          <ul className="flex items-center gap-14 flex-wrap relative">
            {menuItems}
          </ul>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden px-4">
          <ul className="flex flex-col gap-4 items-center justify-center">
            {menuItems}
          </ul>
        </div>
      )}
    </nav>
  );
};