import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import { HiOutlineMenuAlt2 } from "react-icons/hi";
import { FaAngleDown, FaPlus } from "react-icons/fa6";
import { IoClose } from "react-icons/io5";
import { Link } from 'react-router-dom';

export const Categoriespanel = () => {
    const [open, setOpen] = useState(false);
    const [submenuOpen, setSubmenuOpen] = useState(false);

    const toggleDrawer = (newOpen) => () => {
        setOpen(newOpen);
    };

    const toggleSubmenu = () => {
        setSubmenuOpen(!submenuOpen);
    };

    const DrawerList = (
        <Box className="w-[250px] bg-white h-full" role="presentation" onKeyDown={toggleDrawer(false)}>
            <h5 className='pt-3 pl-4 pr-4 flex justify-between items-center text-lg font-semibold'>
                Select Categories
                <IoClose className='h-[30px] w-[30px] cursor-pointer text-gray-600 hover:text-green-500 transition' onClick={toggleDrawer(false)} />
            </h5>
            <Divider />

            <div className="scroll relative px-2 py-2">
                <ul className="w-full">
                    <li className="list-none relative mb-4">
                        <div className='flex items-center justify-between px-2'>
                            <Link to='/' className=''>
                                <Button className='!w-full bg-white hover:bg-white active:bg-white !text-left !justify-start text-black normal-case rounded-md transition '>
                                    Products
                                </Button>
                            </Link>
                            <FaPlus
                                onClick={toggleSubmenu}
                                className={`cursor-pointer transition-transform duration-300 ease-in-out text-gray-600 hover:text-[#7fc119] ${submenuOpen ? 'rotate-45' : 'rotate-0'}`}
                            />
                        </div>

                        {/* Submenu */}
                        <ul className={`transition-all duration-300 ease-in-out overflow-hidden ${submenuOpen ? 'max-h-40 opacity-100 pt-2' : 'max-h-0 opacity-0'}`}>
                            <li className="list-none my-1">
                                <Link to='/' className='link1 block px-6 py-1 text-sm text-black hover:!text-[#7fc119] transition'>
                                    Liquid
                                </Link>
                            </li>
                            <li className="list-none my-1">
                                <Link to='/' className='link1 block px-6 py-1 text-sm text-black hover:!text-[#7fc119] transition'>
                                    Powder
                                </Link>
                            </li>
                            <li className="list-none my-1">
                                <Link to='/' className='link1 block px-6 py-1 text-sm text-black hover:!text-[#7fc119] transition'>
                                    Soap
                                </Link>
                            </li>
                            <li className="list-none my-1">
                                <Link to='/' className='link1 block px-6 py-1 text-sm text-black hover:!text-[#7fc119] transition'>
                                    Soap
                                </Link>
                            </li>
                        </ul>
                    </li>
                        <Link to='/' className=''>
                            <li className="list-none">
                                <Button className='!w-full !justify-start text-black normal-case px-3 rounded-md transition'>
                                    Services
                                </Button>
                            </li>
                        </Link>

                    <Link to='/'>
                        <li className="list-none mt-2">
                            <Button className='!w-full !justify-start text-black normal-case px-3 rounded-md transition'>
                                About Us
                            </Button>
                        </li>
                    </Link>
                </ul>
            </div>
        </Box>
    );

    return (
        <div>
            <Button onClick={toggleDrawer(true)} className='text-black lowercase gap-2 w-full !rounded-[5px] !font-semibold hover:bg-gray-100 transition'>
                <HiOutlineMenuAlt2 className='h-[20px] w-[20px]' />
                Short List
                <FaAngleDown className='text-[15px] ml-auto' />
            </Button>
            <Drawer open={open} onClose={toggleDrawer(false)}>
                {DrawerList}
            </Drawer>
        </div>
    );
};
