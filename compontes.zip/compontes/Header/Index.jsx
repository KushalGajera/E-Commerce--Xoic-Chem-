import React from 'react'
import { Link } from 'react-router-dom'
import Button from '@mui/material/Button';
import { FaCartShopping } from "react-icons/fa6";
import { IoMdHeart } from "react-icons/io";
import Badge from '@mui/material/Badge';
import { IoGitCompare } from "react-icons/io5";
import Tooltip from '@mui/material/Tooltip';
import { Navigation } from './Navigation';
import { MdLocationSearching } from "react-icons/md";
import { MdCall } from "react-icons/md";
import { BsMailbox2 } from "react-icons/bs";
import { MdOutlineDeliveryDining } from "react-icons/md";
import { PiQuestionMarkBold } from "react-icons/pi";

import logo from '/src/assets/logo.png'

export const Header = () => {
  return (
    <header className='bg-[white]'>
      {/* top header */}
      <div className="top-strip hidden sm:block">
        <div className="container">
          <div className="flex items-center justify-between cursor-pointer">
            <div className="flex col1 w-[50%] gap-x-20">
              <p className='text-[12px] font-[500] pt-2'>
                <a href="tel:+919510512938" className='flex gap-2.5 link1 hover:underline'>
                  <MdCall className='text-red-700 !h-[18px] !w-[18px]' />
                  +91 95105 12938
                </a>
              </p>
              <p className='text-[12px] font-[90px] pt-2'>||</p>
              <p className='text-[12px] font-[500] pt-2'>
                <a href="mailto:xoicchem@gmail.com" className='link1 flex gap-2.5 hover:underline'>
                  <BsMailbox2 className='text-red-700 !h-[18px] !w-[18px]' />
                  xoicchem@gmail.com
                </a>
              </p>
            </div>

            <div className="col2 flex items-center justify-end">
              <ul className='flex gap-5 text-[13px] font-[500] items-center'>
                <li className='list-none pt-2 text-red-700'>
                  <Link className='link1 flex gap-2.5' to="/HelpCenter">
                    <PiQuestionMarkBold className='!h-[18px] !w-[18px]' />
                    Help Center
                  </Link>
                </li>
                <li className='list-none pt-2'>
                  <Link className='link1' to="/">||</Link>
                </li>
                <li className='list-none text-red-700 pt-2'>
                  <Link className='link1 flex gap-2.5' to="/OrderTrack">
                    <MdOutlineDeliveryDining className='!h-[18px] !w-[18px]' />
                    Order Tracking
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>




      {/* Middle header */}
      <div className="header">
        <div className="container flex flex-col sm:flex-row sm:items-center sm:justify-between">

          {/* Logo - Hidden on mobile */}
          <div className="col1 pt-2 w-full sm:w-[25%] hidden sm:block">
            <Link className='t1 flex gap-2' to="/">
              <img className='w-15' src={logo} alt="Xoic Chem" />
              {/* <p className=''>Xoic Chem</p> */}
            </Link>
          </div>

          {/* Search Bar - Always visible and responsive */}
          <div className="col2 w-full sm:w-[45%] pt-2 sm:pt-[13px]">
            <div className="serachbox w-full h-[50px] rounded-[7px] relative p-1.5">
              <input
                type="text"
                placeholder="Search For Products.."
                className="in1 w-full h-[35px] focus:outline-0 p-2 bg-inherit text-sm"
              />
              <Button className="serach-icon !absolute top-[8px] right-[5px] z-50 w-[35px] !min-w-[35px] h-[35px] !rounded-full !text-black">
                <MdLocationSearching className="text-black text-[20px]" />
              </Button>
            </div>
          </div>

          {/* Login/Cart - Hidden on mobile */}
          <div className="col3 w-full sm:w-[30%] hidden sm:flex items-center justify-end">
            <ul className="items-center flex gap-3 pt-3">
              <li>
                <Link to="/SignIn">
                  <Button className="gap-1">Sign In</Button>
                </Link>
              </li>

              <li className="flex items-center gap-2 pl-5">
                <Tooltip title="Compare">
                  <Badge
                    badgeContent={4}
                    color="success"
                    sx={{
                      '& .MuiBadge-badge': {
                        fontSize: '8px',
                        minWidth: '8px',
                        height: '16px',
                      },
                    }}
                  >
                    <IoGitCompare className="h-[20px] w-[20px]" />
                  </Badge>
                </Tooltip>
              </li>

              <li>
                <Tooltip title="WishList">
                  <Badge
                    badgeContent={4}
                    color="success"
                    sx={{
                      '& .MuiBadge-badge': {
                        fontSize: '8px',
                        minWidth: '8px',
                        height: '16px',
                      },
                    }}
                  >
                    <IoMdHeart className="h-[20px] w-[20px]" />
                  </Badge>
                </Tooltip>
              </li>

              <li>
                <Tooltip title="Cart">
                  <Badge
                    badgeContent={4}
                    color="success"
                    sx={{
                      '& .MuiBadge-badge': {
                        fontSize: '8px',
                        minWidth: '8px',
                        height: '16px',
                      },
                    }}
                  >
                    <FaCartShopping className="h-[20px] w-[20px]" />
                  </Badge>
                </Tooltip>
              </li>
            </ul>
          </div>

        </div>
      </div>


      <Navigation />

    </header>
  )
}
