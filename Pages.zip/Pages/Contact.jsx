import React, { useState } from 'react';


import { GrLocationPin } from "react-icons/gr";
import { HiOutlineMailOpen } from "react-icons/hi";
import { BiSolidPhoneCall } from "react-icons/bi";
import { MdWatchLater } from "react-icons/md";
import { Link } from 'react-router-dom';
import { FaFacebook } from "react-icons/fa6";
import { BsTwitterX } from "react-icons/bs";
import { RiInstagramFill } from "react-icons/ri";
import { IoLogoWhatsapp } from "react-icons/io";
import { FaYoutube } from "react-icons/fa";
import { IoPaperPlane } from "react-icons/io5";


import Tooltip from '@mui/material/Tooltip';






export const Contact = () => {


    const [formData, setFormData] = useState({
        fullName: '',
        emailAddress: '',
        subject: '',
        message: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Here you would typically send the formData to your backend API
        console.log('Form submitted:', formData);
        alert('Message sent successfully! (Check console for data)');
        // Optionally clear the form
        setFormData({
            fullName: '',
            emailAddress: '',
            subject: '',
            message: ''
        });
    };
    return (
        <>
            <section id="contact" className="contact py-6 bg-gradient-to-r from-[#f0fff0] to-[#eaffea]">
                <div className="min-h-[190px]  flex flex-col items-center justify-center p-4 relative overflow-hidden">
                    <div
                        className="absolute pb-5 lg:text-[5rem] font-extrabold text-black text-opacity-10 uppercase"
                        style={{ letterSpacing: '0.5em', lineHeight: '1', whiteSpace: 'nowrap' }}
                    >
                        CONTACT
                    </div>

                    <h1 className="text-4xl md:text-5xl font-extrabold text-black uppercase tracking-widest mb-2 z-10 opacity-9 flex items-center">
                        CONTACT
                        {/* <span className="w-2 h-2 md:w-3 md:h-3 rounded-full ml-2"></span> */}
                    </h1>

                    <div className="pt-14">
                        <p className="text-sm md:text-base text-black text-center max-w-2xl px-4 z-10 leading-relaxed">
                            hellod sf sfs
                        </p>
                    </div>
                </div>

                <div className="container mx-auto px-4 mt-12 max-w-[1280px]">
                    <div className="grid gap-10 lg:grid-cols-[38%_62%]">
                        {/* Contact Info Panel */}
                        <div className="bg-[#b8e0b8] rounded-2xl p-10 flex flex-col shadow-xl">
                            <div className="mb-8">
                                <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                                <p className="text-sm opacity-85 leading-relaxed">
                                    Dignissimos deleniti accusamus rerum voluptate. Dignissimos rerum sit maiores
                                    reiciendis voluptate inventore ut.
                                </p>
                            </div>

                            {/* left location section */}
                            <div className="grid gap-4">
                                {/* Info Cards */}

                                <div className="bg-green-600 rounded-lg p-3 flex items-center space-x-4 transform transition duration-300 hover:scale-105 hover:bg-green-700 cursor-pointer">
                                    <div className="bg-green-600 p-3 rounded-tl-[30px] rounded-tr-[10px] rounded-br-[30px] rounded-bl-[10px]">
                                        <GrLocationPin size={20} />
                                    </div>
                                    <div>
                                        <p className="text-white font-[300]">Our Location</p>
                                        <p className="text-blue-100 text-sm">4952 Hilltop Dr, Anytown, CA 90210</p>
                                    </div>
                                </div>

                                <div className="bg-green-600 rounded-lg p-3 flex items-center space-x-4 transform transition duration-300 hover:scale-105 hover:bg-green-700 cursor-pointer">
                                    <div className="bg-green-600 p-3 rounded-tl-[10px] rounded-tr-[30px] rounded-br-[10px] rounded-bl-[30px]">
                                        <HiOutlineMailOpen size={20} />
                                    </div>
                                    <div>
                                        <p className="text-white font-[300]">Email Us</p>
                                        <a href='mailto:xoicchem@gmail.com' className="link1 !text-blue-100 text-sm">xoicchem@gmail.com</a>
                                    </div>
                                </div>

                                <div className="bg-green-600 rounded-lg p-3 flex items-center space-x-4 transform transition duration-300 hover:scale-105 hover:bg-green-700 cursor-pointer">
                                    <div className="bg-green-600 p-3 rounded-tl-[30px] rounded-tr-[10px] rounded-br-[30px] rounded-bl-[10px]">
                                        <BiSolidPhoneCall size={20} />
                                    </div>
                                    <div>
                                        <p className="text-white font-[300]">Call Us</p>
                                        <a href='tel:+919510512938' className="link1 !text-blue-100 text-sm">+91 95105 12938</a>
                                    </div>
                                </div>

                                <div className="bg-green-600 rounded-lg p-3 flex items-center space-x-4 transform transition duration-300 hover:scale-105 hover:bg-green-700 cursor-pointer">
                                    <div className="bg-green-600 p-3 rounded-tl-[10px] rounded-tr-[30px] rounded-br-[10px] rounded-bl-[30px]">
                                        <MdWatchLater size={20} />
                                    </div>
                                    <div>
                                        <p className="text-white font-[300]">Working Hours</p>
                                        <p className="text-blue-100 text-sm">Monday-Saturday: 9AM - 9PM</p>
                                    </div>
                                </div>
                            </div>

                            {/* soical media icon */}
                            <div className="pt-44">
                                <h5 className="text-lg font-semibold mb-4">Follow Us</h5>
                                <div className="flex flex-wrap gap-3">

                                    <Tooltip title="FaceBook">
                                        <Link to='/'
                                            className="w-[42px] h-[42px] flex items-center justify-center rounded-full bg-white/15 text-[var(--contrast-color)] text-lg hover:bg-white/30 hover:-translate-y-1 transition-all"
                                        >
                                            <FaFacebook size={20} className='text-green-600' />
                                        </Link>
                                    </Tooltip>

                                    <Tooltip title="Twitter-X">
                                        <Link to='/'
                                            className="w-[42px] h-[42px] flex items-center justify-center rounded-full bg-white/15 text-[var(--contrast-color)] text-lg hover:bg-white/30 hover:-translate-y-1 transition-all"
                                        >
                                            <BsTwitterX size={20} className='text-green-600' /> {/* Or replace with FaTwitter if you have it */}
                                        </Link>
                                    </Tooltip>

                                    <Tooltip title="Instagram">
                                        <Link to='/'
                                            className="w-[42px] h-[42px] flex items-center justify-center rounded-full bg-white/15 text-[var(--contrast-color)] text-lg hover:bg-white/30 hover:-translate-y-1 transition-all"
                                        >
                                            <RiInstagramFill size={20} className='text-green-600' />
                                        </Link>
                                    </Tooltip>

                                    <Tooltip title="Whatsapp">
                                        <Link to='/'
                                            className="w-[42px] h-[42px] flex items-center justify-center rounded-full bg-white/15 text-[var(--contrast-color)] text-lg hover:bg-white/30 hover:-translate-y-1 transition-all"
                                        >
                                            <IoLogoWhatsapp size={20} className='text-green-600' />
                                        </Link>
                                    </Tooltip>

                                    <Tooltip title="YouTube">

                                        <Link to='/'
                                            className="w-[42px] h-[42px] flex items-center justify-center rounded-full bg-white/15 text-[var(--contrast-color)] text-lg hover:bg-white/30 hover:-translate-y-1 transition-all"
                                        >
                                            <FaYoutube size={20} className='text-green-600' />
                                        </Link>
                                    </Tooltip>
                                </div>
                            </div>
                        </div>

                        {/* Contact Form Panel */}
                        <div className="flex flex-col gap-8">
                            <div className="w-full h-[280px] rounded-xl overflow-hidden shadow-lg">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3718.765633512825!2d72.86945987344133!3d21.241140280453674!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f3706ffca93%3A0x44e477c918d4e154!2sXOIC%20Chemicals!5e0!3m2!1sen!2sin!4v1748361751980!5m2!1sen!2sin"
                                    width="100%"
                                    height="100%"
                                    className="border-0"
                                    loading="lazy"
                                    allowFullScreen
                                    referrerPolicy="no-referrer-when-downgrade"
                                    title="Location Map"
                                />
                            </div>

                            <div className="bg-[#1a1a2e] p-8 rounded-lg shadow-xl max-w-2xl mx-auto my-10 transition-all duration-500 ease-in-out">
                                <h2 className="text-white text-3xl font-bold mb-4">Send Us a Message</h2>
                                <p className="text-gray-300 text-sm mb-8">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit mauris hendrerit faucibus imperdiet nec eget felis.
                                </p>

                                <form onSubmit={handleSubmit}>
                                    {/** Full Name */}
                                    <div className="mb-6">
                                        <input
                                            type="text"
                                            name="fullName"
                                            placeholder="Full Name"
                                            value={formData.fullName}
                                            onChange={handleChange}
                                            className="w-full p-3 bg-[#2a2a4a] border border-[#3b3b5b] rounded-md text-white placeholder-gray-400 
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent 
                    transition-all duration-300 ease-in-out focus:shadow-lg"
                                            required
                                        />
                                    </div>

                                    {/** Email */}
                                    <div className="mb-6">
                                        <input
                                            type="email"
                                            name="emailAddress"
                                            placeholder="Email Address"
                                            value={formData.emailAddress}
                                            onChange={handleChange}
                                            className="w-full p-3 bg-[#2a2a4a] border border-[#3b3b5b] rounded-md text-white placeholder-gray-400 
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent 
                    transition-all duration-300 ease-in-out focus:shadow-lg"
                                            required
                                        />
                                    </div>

                                    {/** Subject */}
                                    <div className="mb-6">
                                        <input
                                            type="text"
                                            name="subject"
                                            placeholder="Subject"
                                            value={formData.subject}
                                            onChange={handleChange}
                                            className="w-full p-3 bg-[#2a2a4a] border border-[#3b3b5b] rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 ease-in-out focus:shadow-lg"
                                            required
                                        />
                                    </div>

                                    {/** Message */}
                                    <div className="mb-8">
                                        <textarea
                                            name="message"
                                            placeholder="Your Message"
                                            rows="6"
                                            value={formData.message}
                                            onChange={handleChange}
                                            className="w-full p-3 bg-[#2a2a4a] border border-[#3b3b5b] rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-y transition-all duration-300 ease-in-out focus:shadow-lg"
                                            required
                                        ></textarea>
                                    </div>

                                    {/** Submit Button */}
                                    <button
                                        type="submit"
                                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 !rounded-[10px] flex items-center justify-center space-x-2 transition-all duration-300 ease-in-out hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
                                    >
                                        <span>Send Message</span>
                                        <IoPaperPlane size={18} />
                                    </button>
                                </form>
                            </div>



                        </div>
                    </div>
                </div>
            </section>

        
        </>
    );
};
