import React, { useState, useRef, useEffect } from "react";
import { FiHelpCircle, FiPhone, FiMail, FiMessageCircle } from "react-icons/fi";

const faqData = [
  {
    question: "How can I track my order?",
    answer:
      "You can track your order by visiting the Order Tracking page or clicking the \"Order Tracking\" link in the header.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "We accept all major credit cards, debit cards, and digital wallets like PayPal.",
  },
  {
    question: "How do I return or exchange a product?",
    answer:
      "You can return or exchange products within 30 days of delivery. Please visit our Returns & Exchanges page for detailed instructions.",
  },
];

// SlideDown animation for answers
function SlideDown({ children, isOpen }) {
  const ref = useRef(null);
  const [height, setHeight] = useState("0px");

  useEffect(() => {
    if (ref.current) {
      setHeight(isOpen ? `${ref.current.scrollHeight}px` : "0px");
    }
  }, [isOpen]);

  return (
    <div
      ref={ref}
      style={{
        maxHeight: height,
        transition: "max-height 0.3s ease",
        overflow: "hidden",
      }}
      aria-hidden={!isOpen}
    >
      {children}
    </div>
  );
}

export default function HelpCenter() {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl py-10">
      <h1 className="text-3xl sm:text-4xl font-bold mb-12 text-center text-red-700 tracking-wide">
        Help Center
      </h1>

      {/* FAQ Section */}
      <section className="mb-16">
        <h2 className="text-2xl sm:text-3xl font-semibold mb-8 border-b border-gray-300 pb-2 text-gray-800">
          Frequently Asked Questions (FAQs)
        </h2>

        <div className="flex flex-col divide-y divide-gray-200">
          {faqData.map(({ question, answer }, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div key={idx} className="py-4">
                <button
                  onClick={() => toggleFAQ(idx)}
                  className="w-full flex items-center justify-between focus:outline-none"
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${idx}`}
                  id={`faq-question-${idx}`}
                >
                  <div className="flex items-center gap-3">
                    <FiHelpCircle
                      className={`text-red-600 text-xl transition-colors duration-300 ${
                        isOpen ? "text-red-800" : "hover:text-red-700"
                      }`}
                    />
                    <span
                      className={`font-medium text-lg sm:text-xl text-gray-800 transition-colors duration-300 hover:text-red-700 ${
                        isOpen ? "text-red-700 underline" : ""
                      }`}
                    >
                      {question}
                    </span>
                  </div>

                  <svg
                    className={`w-6 h-6 text-red-600 transition-transform duration-300 ${
                      isOpen ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>

                <SlideDown isOpen={isOpen}>
                  <p
                    id={`faq-answer-${idx}`}
                    role="region"
                    aria-labelledby={`faq-question-${idx}`}
                    className="mt-4 text-gray-700 leading-relaxed px-10 sm:px-12"
                  >
                    {answer}
                  </p>
                </SlideDown>
              </div>
            );
          })}
        </div>
      </section>

      {/* Contact Support Section */}
      <section>
        <h2 className="text-2xl sm:text-3xl font-semibold mb-6 border-b border-gray-300 pb-2 text-gray-800">
          Contact Support
        </h2>

        <p className="text-gray-700 mb-8 max-w-prose mx-auto text-center sm:text-left text-base tracking-wide leading-relaxed">
          If you need further assistance, feel free to contact us:
        </p>

        <ul className="max-w-prose mx-auto sm:mx-0 space-y-5 text-center sm:text-left">
          <li className="flex items-center justify-center sm:justify-start gap-3 text-gray-700 hover:text-red-700 transition-colors duration-300 cursor-pointer">
            <FiPhone className="text-red-600 w-6 h-6" />
            <a
              href="tel:+919510512938"
              className="underline hover:no-underline text-lg sm:text-base"
            >
              +91 95105 12938
            </a>
          </li>

          <li className="flex items-center justify-center sm:justify-start gap-3 text-gray-700 hover:text-red-700 transition-colors duration-300 cursor-pointer">
            <FiMail className="text-red-600 w-6 h-6" />
            <a
              href="mailto:xoicchem@gmail.com"
              className="underline hover:no-underline text-lg sm:text-base"
            >
              xoicchem@gmail.com
            </a>
          </li>

          <li className="flex items-center justify-center sm:justify-start gap-3 text-gray-500 italic text-base">
            <FiMessageCircle className="w-6 h-6" />
            <span>Live Chat: Available 9am - 6pm IST on weekdays.</span>
          </li>
        </ul>
      </section>
    </div>
  );
}
