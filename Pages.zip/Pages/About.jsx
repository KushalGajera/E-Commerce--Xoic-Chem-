import React from 'react'

export const About = () => {
  return (
    <>
      <div className="min-h-[190px]  flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div
          className="absolute pb-5 lg:text-[5rem] font-extrabold text-black text-opacity-10 uppercase"
          style={{ letterSpacing: '0.5em', lineHeight: '1', whiteSpace: 'nowrap' }}
        >
          About
        </div>

        <h1 className="text-4xl md:text-5xl font-extrabold text-black uppercase tracking-widest mb-2 z-10 opacity-9 flex items-center">
          About
          {/* <span className="w-2 h-2 md:w-3 md:h-3 rounded-full ml-2"></span> */}
        </h1>

        <div className="pt-14">
          <p className="text-sm md:text-base text-black text-center max-w-2xl px-4 z-10 leading-relaxed">
            hellod sf sfs
          </p>
        </div>
      </div>
    </>
  )
}
