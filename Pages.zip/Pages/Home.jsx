import React, { useState } from 'react';
import { HomeSlider } from '../compontes/HomeSlider';
import { HomeCatSlider } from '../compontes/HomeCatSlider';
import { TbTruckDelivery } from 'react-icons/tb';
import { Listslider } from '../compontes/Listslider';
import { Secondproslider } from '../compontes/Secondproslider';
import { Footer } from '../compontes/Footer';


export const Home = () => {

  return (
    <>
      <HomeSlider />
      <HomeCatSlider />

      {/* Free Shipping Section */}
      <section className="bg-gradient-to-r from-[#f0fff0] to-[#eaffea] py-6 ">
        <div className="container">
          <div className="container mx-auto px-3">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-4 border-2 border-[#7fc119] rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300 bg-white">

              {/* Icon */}
              <div className="flex-shrink-0 animate-pulse">
                <TbTruckDelivery className="text-[#7fc119] w-14 h-14 sm:w-16 sm:h-16" />
              </div>

              {/* Text */}
              <div className="text-center sm:text-left">
                <h2 className="text-3xl sm:text-4xl font-bold text-gray-800 mb-2">
                  Free Shipping & Fast Delivery
                </h2>
                <p className="text-lg text-gray-600">
                  Enjoy free delivery on all orders above $50 - quick, safe, and reliable!
                </p>
              </div>

              {/* Call to Action (Optional) */}
              <div className="mt-3.5 sm:mt-0">
                <button className="bg-[#7fc119] hover:bg-[#6cb30f] text-white font-semibold px-6 py-3 !rounded-[10px] transition duration-300">
                  Shop Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Listslider/>
      <Secondproslider/>

    </>
  );
};
