import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Typography,
  Button,
  MenuItem,
  Select,
  TextField
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

export const ProductQuickViewDialog = ({ open, onClose, product }) => {
  const [selectedWeight, setSelectedWeight] = useState(product?.weights?.[0] || '');
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ m: 0, p: 2 }}>
        <Typography variant="h6">{product.name}</Typography>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{ position: 'absolute', right: 8, top: 8, color: 'gray' }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers>
        <div className="flex flex-col md:flex-row gap-6 items-start">
          <div className="w-full md:w-1/2">
            <img
              src={product.images?.[0]}
              alt={product.name}
              className="rounded-xl w-full object-contain max-h-[300px]"
            />
          </div>
          <div className="w-full md:w-1/2 space-y-4">
            <Typography>{product.description}</Typography>
            <Typography variant="h6" color="green">${product.price}</Typography>

            <div>
              <Typography>Select Weight:</Typography>
              <Select
                fullWidth
                value={selectedWeight}
                onChange={(e) => setSelectedWeight(e.target.value)}
              >
                {product.weights.map((w) => (
                  <MenuItem key={w} value={w}>{w}</MenuItem>
                ))}
              </Select>
            </div>

            <div>
              <Typography>Quantity:</Typography>
              <TextField
                fullWidth
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, +e.target.value))}
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="contained" color="success">Add to Cart</Button>
              <Button variant="outlined">❤️ Like</Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
