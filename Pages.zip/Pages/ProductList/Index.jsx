import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import bg1 from '/src/assets/products/bg-1.png';
import bg2 from '/src/assets/products/bg-2.png';
import bg3 from '/src/assets/products/bg-3.png';

import { useLocation } from 'react-router-dom';
import { useEffect } from 'react';




const categories = ['All', 'Liquid', 'Plastic', 'Powder', 'Soap', 'Solar'];
const subcategories = {
    Powder: ['100 gm', '500 gm', '1 kg', '5 kg'],
    Liquid: ['1L', '5L', '10L'],
};

const products = [
    {
        id: 1,
        name: 'Glass Cleaner',
        category: 'Liquid',
        subcategory: '1L',
        price: 70,
        description: 'Effective cleaner for glass and mirrors.',
        img: bg1,
    },
    {
        id: 2,
        name: 'T-Shirt',
        category: 'Plastic',
        price: 29,
        description: 'Comfortable cotton t-shirt.',
        img: bg2,
    },
    {
        id: 3,
        name: 'Washing Powder',
        category: 'Powder',
        subcategory: '500 gm',
        price: 89,
        description: 'Powerful cleaning powder.',
        img: 'https://via.placeholder.com/150',
    },
    {
        id: 4,
        name: 'Book: React Basics',
        category: 'Soap',
        price: 19,
        description: 'Beginner guide to React.',
        img: 'https://via.placeholder.com/150',
    },
    {
        id: 5,
        name: 'Solar Brush',
        category: 'Solar',
        price: 1500,
        description: 'Efficient solar-powered brush.',
        img: bg3,
    },
    {
        id: 6,
        name: 'Liquid Detergent',
        category: 'Liquid',
        subcategory: '5L',
        price: 90,
        description: 'Gentle and effective detergent.',
        img: bg1,
    },
];

export const ProductList = () => {

    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const categoryParam = params.get('category');

        if (categoryParam && categories.includes(categoryParam)) {
            setActiveCategory(categoryParam);
            setActiveSubcategory(null); // Optional: reset subcategory when category changes
        }
    }, [location.search]);

    const [activeCategory, setActiveCategory] = useState('All');
    const [activeSubcategory, setActiveSubcategory] = useState(null);

    const filteredProducts = products.filter((product) => {
        const matchCategory = activeCategory === 'All' || product.category === activeCategory;
        const matchSub = !subcategories[activeCategory]?.length || !activeSubcategory || product.subcategory === activeSubcategory;
        return matchCategory && matchSub;
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-100 to-white p-6">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">

                {/* Sidebar */}
                <aside className="bg-white rounded-3xl shadow-lg p-6 md:col-span-1 space-y-8 border border-gray-200">
                    <div>
                        <h2 className="text-xl font-bold mb-4 text-gray-800">Categories</h2>
                        <div className="space-y-2">
                            {categories.map(cat => (
                                <button
                                    key={cat}
                                    onClick={() => {
                                        setActiveCategory(cat);
                                        setActiveSubcategory(null);
                                    }}
                                    className={`w-full text-left px-4 py-2 rounded-full border transition duration-200 font-medium ${activeCategory === cat
                                        ? 'bg-green-500 text-white border-green-500'
                                        : 'bg-gray-100 text-gray-800 hover:bg-green-100 hover:border-green-300'
                                        }`}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Subcategories */}
                    {activeCategory in subcategories && (
                        <div>
                            <h3 className="text-md font-semibold text-gray-700 mb-3">Size</h3>
                            <div className="flex flex-wrap gap-2">
                                <label className="cursor-pointer">
                                    <input
                                        type="radio"
                                        className="hidden peer"
                                        name="sub"
                                        value=""
                                        checked={!activeSubcategory}
                                        onChange={() => setActiveSubcategory(null)}
                                    />
                                    <div className="peer-checked:bg-green-500 peer-checked:text-white px-3 py-1.5 rounded-full bg-gray-200 text-gray-700 transition">
                                        All
                                    </div>
                                </label>
                                {subcategories[activeCategory].map(sub => (
                                    <label key={sub} className="cursor-pointer">
                                        <input
                                            type="radio"
                                            className="hidden peer"
                                            name="sub"
                                            value={sub}
                                            checked={activeSubcategory === sub}
                                            onChange={() => setActiveSubcategory(sub)}
                                        />
                                        <div className="peer-checked:bg-green-500 peer-checked:text-white px-3 py-1.5 rounded-full bg-gray-200 text-gray-700 transition">
                                            {sub}
                                        </div>
                                    </label>
                                ))}
                            </div>
                        </div>
                    )}
                </aside>

                {/* Product Grid */}
                <section className="md:col-span-3">
                    <h2 className="text-2xl font-bold mb-6 text-gray-800">
                        {activeCategory} Products
                    </h2>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredProducts.map(product => (
                            <div
                                key={product.id}
                                className="bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 transform hover:scale-[1.02] flex flex-col"
                            >
                                <Link to="#" className="block overflow-hidden">
                                    <img
                                        src={product.img}
                                        alt={product.name}
                                        className="w-full h-48 object-contain bg-gray-50 p-4 transition-transform duration-300 hover:scale-105"
                                    />
                                </Link>
                                <div className="p-4 flex-1 flex flex-col">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-1">{product.name}</h3>
                                    <p className="text-sm text-gray-500 mb-1">{product.category}</p>
                                    {product.subcategory && (
                                        <p className="text-xs text-gray-400">{product.subcategory}</p>
                                    )}
                                    <p className="text-sm text-gray-600 mb-3">{product.description}</p>
                                    <div className="mt-auto flex justify-between items-center">
                                        <p className="text-green-600 font-bold text-lg">${product.price}</p>
                                        <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-1.5 rounded-full transition">
                                            Add to Cart
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {filteredProducts.length === 0 && (
                            <p className="col-span-full text-center text-gray-400 mt-10">No products match your filters.</p>
                        )}
                    </div>
                </section>
            </div>
        </div>
    );
};