import React from 'react'
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";

import { HiOutlineTrendingUp } from "react-icons/hi";


import banner1 from '../assets/products/banner1.jpg'
import banner2 from '../assets/products/banner2.jpg'
import banner3 from '../assets/products/banner3.jpg'

export const Blog = () => {

  const accentColor = '#3B82F6'; // Example: Tailwind blue-500
  const contrastColor = '#ffffff';
  const surfaceColor = '#f9fafb';

  const posts = [
    {
      id: 1,
      image: banner1,
      author: "Julia Parker",
      date: "Jan 15, 2025",
      comments: 6,
      title: "Liquid is perfect to all clen cloth",
      excerpt: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, adipisci!",
    },
    {
      id: 2,
      image: banner2,
      author: "Mark Wilson",
      date: "Jan 18, 2025",
      comments: 6,
      title: "Glass clener is best clen",
      excerpt: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, adipisci!",
    },
    {
      id: 3,
      image: banner3,
      author: "Sarah Johnson",
      date: "Jan 21, 2025",
      comments: 15,
      title: "Solar wiper clen to solar plate",
      excerpt: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, adipisci!",
    },
    {
      id: 4,
      image: banner1,
      author: "David Brown",
      date: "Jan 24, 2025",
      comments: 10,
      title: "Liquid is perfect to all clen cloth",
      excerpt:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, adipisci!",
    },
    {
      id: 5,
      image: banner2,
      author: "Emma Davis",
      date: "Jan 27, 2025",
      comments: 6,
      title: "Glass clener is best clen",
      excerpt:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, adipisci!",
    },
  ];

  return (
    <>
      <section className="bg-gradient-to-r from-[#f0fff0] to-[#eaffea] p-4 ">
        <div className="min-h-[190px]  flex flex-col items-center justify-center relative overflow-hidden">
          <div
            className="absolute pb-5 lg:text-[5rem] font-extrabold text-black text-opacity-10 uppercase"
            style={{ letterSpacing: '0.5em', lineHeight: '1', whiteSpace: 'nowrap' }}
          >
            Blog & News
          </div>

          <h1 className="text-4xl md:text-5xl font-extrabold text-black uppercase tracking-widest mb-2 z-10 opacity-9 flex items-center">
            Blog & News
            {/* <span className="w-2 h-2 md:w-3 md:h-3 rounded-full ml-2"></span> */}
          </h1>

          <div className="pt-14">
            <p className="text-sm md:text-base text-black text-center max-w-2xl px-4 z-10 leading-relaxed">
              News are Avaliable in website
            </p>
          </div>
        </div>



        <div className="container mx-auto px-4">


          {/* Swiper Slider */}
          <div data-aos="fade-up" data-aos-delay="100">
            <Swiper
              modules={[Autoplay]}
              loop
              speed={800}
              autoplay={{ delay: 5000 }}
              spaceBetween={30}
              breakpoints={{
                320: { slidesPerView: 1, spaceBetween: 20 },
                768: { slidesPerView: 2, spaceBetween: 20 },
                1200: { slidesPerView: 3, spaceBetween: 30 },
              }}
            >
              {posts.map((post) => (
                <SwiperSlide key={post.id}>
                  <div className="rounded-lg overflow-hidden bg-gray-200">
                    <img
                      src={post.image}
                      alt="Blog"
                      className="w-full h-64 object-cover"
                    />
                    <div className="p-5">
                      <div className="text-sm text-gray-500 space-x-4 mb-3">
                        <span>
                          <i className="bi bi-person mr-1"></i>
                          {post.author}
                        </span>
                        <span>
                          <i className="bi bi-clock mr-1"></i>
                          {post.date}
                        </span>
                        <span>
                          <i className="bi bi-chat-dots mr-1"></i>
                          {post.comments} Comments
                        </span>
                      </div>
                      <h2 className="text-xl font-semibold mb-2">
                        <a href="#" className="link1 hover:text-blue-600">
                          {post.title}
                        </a>
                      </h2>
                      <p className="text-gray-600 text-sm mb-4">{post.excerpt}</p>
                      {/* <a
                        href="#"
                        className="link1 text-blue-600 font-medium inline-flex items-center gap-1 hover:underline"
                      >
                        Read More <i className="bi bi-arrow-right"></i>
                      </a> */}
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>


        <div className='py-16 px-6 md:px-20'>
          <div className="pt-5 max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12">
            {/* Left Content */}
            <div className="flex-1">
              {/* Badge */}
              <div className="inline-block bg-[#cff3c8] text-[#7fc119] px-4 py-1 rounded-full font-semibold text-sm mb-4 uppercase">
                Don’t Miss
              </div>

              {/* Title */}
              <h2 className="text-4xl md:text-5xl font-bold text-[#1f2b3d] leading-tight">
                Hair Clener
              </h2>

              {/* Description */}
              <p className="mt-4 text-lg text-[#4a5568]">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, nulla!
              </p>

              {/* Features */}
              <div className="mt-6 flex flex-wrap gap-4">
                {[
                  'Premium Quality',
                  'Best Price',
                  'Top Quality',
                ].map((feature, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg shadow-md bg-white"
                  >
                    <div className="text-[#7fc119] text-lg">
                      <i className="bi bi-check-circle-fill"></i>
                    </div>
                    <span className="text-[#1f2b3d] font-medium">{feature}</span>
                  </div>
                ))}
              </div>

              {/* Buttons */}
              <div className="mt-8 flex gap-4 flex-wrap">
                <a
                  href="#"
                  className="link1 border-2 border-[#7fc119] text-[#7fc119] hover:bg-[#7fc119] hover:!text-white px-6 py-3 rounded-md font-semibold transition"
                >
                  Learn More
                </a>
              </div>
            </div>

            {/* Right Image */}
            <div className="flex-1 relative">
              <img
                src={banner1}
                alt="Coffee and productivity"
                className="rounded-2xl shadow-xl w-full max-w-md mx-auto"
              />
              {/* Floating Card */}
              <div className="absolute bottom-6 right-6 bg-gradient-to-r from-[#f0fff0] to-[#eaffea] rounded-xl shadow-lg px-3 py-3 flex items-center gap-3">
                <div className="p-3 bg-[#ffe5d6] rounded-lg text-[#7fc119]">
                  <HiOutlineTrendingUp size={20} />
                </div>
                <div>
                  <div className="text-2xl font-bold text-[#7fc119]">45%</div>
                  <div className="text-sm text-gray-500">Growth Rate</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      
    </>
  )
}
