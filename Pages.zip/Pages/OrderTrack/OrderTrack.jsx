import React, { useState } from "react";
import { FaBox, FaShippingFast, FaTruckMoving, FaCheckCircle } from "react-icons/fa";

const steps = [
  {
    label: "Order Placed",
    icon: <FaBox className="text-white w-5 h-5" />,
    status: "completed",
  },
  {
    label: "Shipped",
    icon: <FaShippingFast className="text-white w-5 h-5" />,
    status: "completed",
  },
  {
    label: "Out for Delivery",
    icon: <FaTruckMoving className="text-white w-5 h-5" />,
    status: "active",
  },
  {
    label: "Delivered",
    icon: <FaCheckCircle className="text-white w-5 h-5" />,
    status: "upcoming",
  },
];

export default function OrderTrack() {
  const [orderId, setOrderId] = useState("");

  return (
    <div className="container mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl sm:text-4xl font-bold text-center text-red-700 mb-10">Track Your Order</h1>

      {/* Order input section */}
      <div className="bg-gray-50 p-6 rounded-xl shadow-md mb-10">
        <label className="block text-lg font-medium text-gray-700 mb-2">Enter Order ID</label>
        <input
          type="text"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="e.g., XOIC123456"
          className="w-full border border-gray-300 p-3 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 mb-4"
        />
        <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-md transition-all w-full sm:w-auto">
          Track Order
        </button>
      </div>

      {/* Order status progress */}
      <div className="flex flex-col gap-8 sm:gap-6">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center gap-4">
            <div
              className={`flex items-center justify-center w-10 h-10 rounded-full ${
                step.status === "completed"
                  ? "bg-green-600"
                  : step.status === "active"
                  ? "bg-yellow-500 animate-pulse"
                  : "bg-gray-400"
              }`}
            >
              {step.icon}
            </div>
            <div>
              <p
                className={`text-lg font-semibold ${
                  step.status === "completed"
                    ? "text-green-700"
                    : step.status === "active"
                    ? "text-yellow-700"
                    : "text-gray-500"
                }`}
              >
                {step.label}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
