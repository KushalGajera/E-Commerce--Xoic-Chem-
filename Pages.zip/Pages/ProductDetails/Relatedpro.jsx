import React from 'react';
import { HiMiniShoppingBag } from 'react-icons/hi2';
import { IoEyeSharp } from 'react-icons/io5';
import { IoMdHeart } from 'react-icons/io';
import pro1 from '/src/assets/products/bg-1.png';
import { Button } from '@mui/material';

export const Relatepro = () => {
    return (
        <section className='bg-gray-100'>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 p-6 bg-gray-100">
                {/* Product Card */}
                <div className="relative bg-white rounded-3xl shadow-md overflow-hidden p-4 group transition-all duration-500 hover:shadow-2xl hover:scale-[1.02] hover:border-blue-500 border border-transparent">
                    {/* Hover Action Icons */}
                    <div className="absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 z-20">
                        <button
                            title="Add to Wishlist"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoMdHeart className="text-[#7fc119] w-5 h-5" />
                        </button>
                        <button
                            title="Quick View"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoEyeSharp className="text-[#7fc119] w-5 h-5" />
                        </button>
                    </div>

                    {/* Image */}
                    <div className="flex items-center justify-center my-6 overflow-hidden rounded-xl">
                        <img
                            src={pro1}
                            alt="Product"
                            className="h-40 object-contain transition-transform duration-500 ease-in-out group-hover:scale-110"
                        />
                    </div>

                    {/* Product Details */}
                    <div className="transition-opacity duration-500 ease-in-out group-hover:opacity-100 opacity-95">
                        <h3 className="text-center text-base font-semibold text-gray-800 mb-2">
                            Glass Cleaner
                        </h3>
                        <div className="text-center text-lg font-bold text-gray-900 mb-1">
                            $89.99
                        </div>
                        <div className="flex justify-center items-center text-yellow-400 text-sm mb-4">
                            ★★★★☆
                            <span className="ml-2 text-gray-500">(42)</span>
                        </div>

                        {/* Add to Cart */}
                        <button className="w-full bg-[#7fc119] text-white py-2 px-4 !rounded-xl flex items-center justify-center gap-2 hover:bg-[#8fc125] hover:scale-[1.02] active:scale-100 transition-all duration-300 shadow-md hover:shadow-lg">
                            <HiMiniShoppingBag className="w-5 h-5" />
                            Add to Cart
                        </button>
                    </div>
                </div>

                {/* Product Card */}
                <div className="relative bg-white rounded-3xl shadow-md overflow-hidden p-4 group transition-all duration-500 hover:shadow-2xl hover:scale-[1.02] hover:border-blue-500 border border-transparent">
                    {/* Hover Action Icons */}
                    <div className="absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 z-20">
                        <button
                            title="Add to Wishlist"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoMdHeart className="text-[#7fc119] w-5 h-5" />
                        </button>
                        <button
                            title="Quick View"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoEyeSharp className="text-[#7fc119] w-5 h-5" />
                        </button>
                    </div>

                    {/* Image */}
                    <div className="flex items-center justify-center my-6 overflow-hidden rounded-xl">
                        <img
                            src={pro1}
                            alt="Product"
                            className="h-40 object-contain transition-transform duration-500 ease-in-out group-hover:scale-110"
                        />
                    </div>

                    {/* Product Details */}
                    <div className="transition-opacity duration-500 ease-in-out group-hover:opacity-100 opacity-95">
                        <h3 className="text-center text-base font-semibold text-gray-800 mb-2">
                            Glass Cleaner
                        </h3>
                        <div className="text-center text-lg font-bold text-gray-900 mb-1">
                            $89.99
                        </div>
                        <div className="flex justify-center items-center text-yellow-400 text-sm mb-4">
                            ★★★★☆
                            <span className="ml-2 text-gray-500">(42)</span>
                        </div>

                        {/* Add to Cart */}
                        <button className="w-full bg-[#7fc119] text-white py-2 px-4 !rounded-xl flex items-center justify-center gap-2 hover:bg-[#8fc125] hover:scale-[1.02] active:scale-100 transition-all duration-300 shadow-md hover:shadow-lg">
                            <HiMiniShoppingBag className="w-5 h-5" />
                            Add to Cart
                        </button>
                    </div>
                </div>
                {/* Product Card */}
                <div className="relative bg-white rounded-3xl shadow-md overflow-hidden p-4 group transition-all duration-500 hover:shadow-2xl hover:scale-[1.02] hover:border-blue-500 border border-transparent">
                    {/* Hover Action Icons */}
                    <div className="absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 z-20">
                        <button
                            title="Add to Wishlist"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoMdHeart className="text-[#7fc119] w-5 h-5" />
                        </button>
                        <button
                            title="Quick View"
                            className="p-2 !rounded-full shadow-md hover:bg-[#c7f8add8] transition-transform hover:scale-110"
                        >
                            <IoEyeSharp className="text-[#7fc119] w-5 h-5" />
                        </button>
                    </div>

                    {/* Image */}
                    <div className="flex items-center justify-center my-6 overflow-hidden rounded-xl">
                        <img
                            src={pro1}
                            alt="Product"
                            className="h-40 object-contain transition-transform duration-500 ease-in-out group-hover:scale-110"
                        />
                    </div>

                    {/* Product Details */}
                    <div className="transition-opacity duration-500 ease-in-out group-hover:opacity-100 opacity-95">
                        <h3 className="text-center text-base font-semibold text-gray-800 mb-2">
                            Glass Cleaner
                        </h3>
                        <div className="text-center text-lg font-bold text-gray-900 mb-1">
                            $89.99
                        </div>
                        <div className="flex justify-center items-center text-yellow-400 text-sm mb-4">
                            ★★★★☆
                            <span className="ml-2 text-gray-500">(42)</span>
                        </div>

                        {/* Add to Cart */}
                        <button className="w-full bg-[#7fc119] text-white py-2 px-4 !rounded-xl flex items-center justify-center gap-2 hover:bg-[#8fc125] hover:scale-[1.02] active:scale-100 transition-all duration-300 shadow-md hover:shadow-lg">
                            <HiMiniShoppingBag className="w-5 h-5" />
                            Add to Cart
                        </button>
                    </div>
                </div>
                

            </div>
        </section>
    );

};
