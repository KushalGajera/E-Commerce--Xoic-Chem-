import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';

import bg1 from '/src/assets/products/bg-1.png';
import bg2 from '/src/assets/products/bg-2.png';
import bg3 from '/src/assets/products/bg-3.png';

import { Relatepro } from '../../Pages/ProductDetails/Relatedpro';

export const ProductDetails = () => {
  const { id } = useParams();

  const products = [
    {
      id: 1,
      name: 'Glass Cleaner',
      category: 'Liquid',
      weights: ['500ml', '1L', '5L'],
      price: 70,
      description: 'Effective cleaner for glass and mirrors. Provides streak-free shine.',
      rating: 4.8,
      images: [bg1, bg2, bg3],
    },
    {
      id: 2,
      name: 'Glass Cleaner 2',
      category: 'Spray',
      weights: ['250ml', '500ml'],
      price: 50,
      description: 'Glass cleaner with lemon fragrance.',
      rating: 4.2,
      images: [bg2, bg3],
    },
  ];

  const product = products.find((p) => p.id === parseInt(id));
  const [selectedWeight, setSelectedWeight] = useState(product?.weights[0]);
  const [selectedImg, setSelectedImg] = useState(product?.images[0]);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return <div className="p-10 text-center text-lg text-red-500">Product not found.</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-8">
      <div className="max-w-6xl mx-auto bg-white rounded-3xl shadow-xl p-6 sm:p-10 border border-gray-200">
        <div className="flex flex-col md:flex-row gap-10">
          {/* Product Image */}
          <div className="flex-1">
            <img
              src={selectedImg}
              alt={product.name}
              className="w-full h-96 object-contain rounded-2xl border border-gray-300 shadow-md hover:scale-105 transition-transform duration-300"
            />
            <div className="flex gap-3 mt-5">
              {product.images.map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt="Thumbnail"
                  className={`h-20 w-20 object-cover border rounded-xl cursor-pointer transition-all duration-200 hover:ring-2 hover:ring-green-400 ${
                    selectedImg === img ? 'ring-2 ring-green-600' : ''
                  }`}
                  onClick={() => setSelectedImg(img)}
                />
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="flex-1 flex flex-col space-y-5">
            <h1 className="text-4xl font-bold text-gray-900">{product.name}</h1>
            <p className="text-sm text-gray-500 uppercase tracking-wide">{product.category}</p>
            <p className="text-gray-700 leading-relaxed">{product.description}</p>
            <p className="text-3xl font-extrabold text-green-600">${product.price}</p>

            {/* Rating */}
            <div className="text-yellow-500 text-lg font-semibold">
              {'⭐'.repeat(Math.floor(product.rating))}{' '}
              <span className="text-gray-600 text-sm">({product.rating})</span>
            </div>

            {/* Weight Selector */}
            <div>
              <label className="block text-gray-700 font-medium mb-1">Select Weight:</label>
              <select
                value={selectedWeight}
                onChange={(e) => setSelectedWeight(e.target.value)}
                className="border border-gray-300 rounded-lg px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-green-400"
              >
                {product.weights.map((weight) => (
                  <option key={weight} value={weight}>
                    {weight}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity Selector */}
            <div>
              <label className="block text-gray-700 font-medium mb-1">Quantity:</label>
              <input
                type="number"
                value={quantity}
                min="1"
                onChange={(e) => setQuantity(parseInt(e.target.value))}
                className="border border-gray-300 rounded-lg px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-green-400"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 flex-wrap mt-4">
              <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full shadow-md transition">
                Add to Cart
              </button>
              <button className="border border-gray-400 text-gray-700 px-6 py-2 rounded-full hover:bg-gray-100 transition">
                ❤️ Like
              </button>
              <button className="border border-gray-400 text-gray-700 px-6 py-2 rounded-full hover:bg-gray-100 transition">
                ⚖️ Compare
              </button>
            </div>

            <Link to="/" className="text-green-600 hover:underline mt-4 inline-block font-medium">
              ← Back to Products
            </Link>
          </div>
        </div>

        {/* Info, Reviews, and Feedback */}
        <div className="mt-12 space-y-6">
          <details className="border border-gray-200 rounded-lg overflow-hidden">
            <summary className="bg-gray-100 px-4 py-3 cursor-pointer font-semibold text-gray-800">
              📦 Additional Information
            </summary>
            <div className="px-4 py-4 text-gray-600 text-sm leading-relaxed">
              <ul className="list-disc pl-6 space-y-1">
                <li>Weight options: {product.weights.join(', ')}</li>
                <li>Available in eco-friendly packaging</li>
                <li>Made in India</li>
              </ul>
            </div>
          </details>

          <details className="border border-gray-200 rounded-lg overflow-hidden">
            <summary className="bg-gray-100 px-4 py-3 cursor-pointer font-semibold text-gray-800">
              📝 Customer Reviews
            </summary>
            <div className="px-4 py-4 text-gray-700 space-y-4">
              <div className="border-b pb-2">
                <p className="font-medium text-sm text-gray-600">⭐ 5.0 by John Doe</p>
                <p>Left my windows sparkling clean. Loved it!</p>
              </div>
              <div className="border-b pb-2">
                <p className="font-medium text-sm text-gray-600">⭐ 4.0 by Jane Smith</p>
                <p>Good product, but wish it had a better spray nozzle.</p>
              </div>
            </div>
          </details>

          <details className="border border-gray-200 rounded-lg overflow-hidden">
            <summary className="bg-gray-100 px-4 py-3 cursor-pointer font-semibold text-gray-800">
              💬 Leave Your Feedback
            </summary>
            <div className="px-4 py-4">
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full border border-gray-300 px-4 py-2 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-400"
                />
                <textarea
                  placeholder="Your Review"
                  rows="3"
                  className="w-full border border-gray-300 px-4 py-2 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-400"
                ></textarea>
                <select className="w-full border border-gray-300 px-4 py-2 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-400">
                  <option value="">Rating</option>
                  <option value="5">⭐ 5</option>
                  <option value="4">⭐ 4</option>
                  <option value="3">⭐ 3</option>
                  <option value="2">⭐ 2</option>
                  <option value="1">⭐ 1</option>
                </select>
                <button
                  type="submit"
                  className="bg-green-600 text-white px-6 py-2 rounded-full shadow-md hover:bg-green-700 transition"
                >
                  Submit Feedback
                </button>
              </form>
            </div>
          </details>
        </div>

        {/* Related Products */}
        <div className="container w-full items-center justify-between pt-5 pb-3 namelist">
          <h3>Related Products</h3>
        </div>
        <Relatepro />
      </div>
    </div>
  );
};
