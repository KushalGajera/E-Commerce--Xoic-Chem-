import React from 'react'
import { BsLightbulb, BsBarChart, BsPeople, BsGraphUpArrow } from "react-icons/bs";

import { TbTruckDelivery } from "react-icons/tb";
import { GiReturnArrow } from "react-icons/gi";
import { HiOutlineCash } from "react-icons/hi";




export const Services = () => {
  return (
    <>
      <section id="contact" className="contact py-6 bg-gradient-to-r from-[#f0fff0] to-[#eaffea]">
        <div className="min-h-[190px]  flex flex-col items-center justify-center p-4 relative overflow-hidden">
          <div
            className="absolute pb-5 lg:text-[5rem] font-extrabold text-black text-opacity-10 uppercase"
            style={{ letterSpacing: '0.5em', lineHeight: '1', whiteSpace: 'nowrap' }}
          >
            Services
          </div>

          <h1 className="text-4xl md:text-5xl font-extrabold text-black uppercase tracking-widest mb-2 z-10 opacity-9 flex items-center">
            Services
            {/* <span className="w-2 h-2 md:w-3 md:h-3 rounded-full ml-2"></span> */}
          </h1>

          <div className="pt-14">
            <p className="text-sm md:text-base text-black text-center max-w-2xl px-4 z-10 leading-relaxed">
              All Services are available
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-16" data-aos="fade-up" data-aos-delay="100">

          {/* Header Section */}
          <div className="mb-16 md:mb-12 border bg-[#adedb8] rounded-tl-[100px] rounded-br-[100px] p-5">
            <div className="flex flex-col lg:flex-row gap-8">

              {/* Intro */}
              <div className="lg:w-3/4 pr-8 md:pr-0 md:mb-10" data-aos="fade-right">
                <div>
                  <div className="inline-block bg-[#27a03b] text-white text-sm font-semibold px-5 py-2 rounded-tr-[20px] rounded-bl-[20px] mb-6 uppercase tracking-wider">
                    Products Consulting
                  </div>
                  <h2 className="text-4xl md:text-3xl font-bold mb-6 leading-tight text-gray-900">
                    Transform Your Business With Expert Consulting Solutions
                  </h2>
                  <p className="text-base text-gray-700 leading-relaxed mb-4">
                    We help organizations navigate complex challenges, identify growth opportunities, and implement effective strategies to achieve sustainable success in today's competitive landscape.
                  </p>
                  <p className="text-base text-gray-700 leading-relaxed">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vehicula metus at libero finibus, in egestas nibh imperdiet...
                  </p>
                </div>
              </div>

              {/* Stats */}
              <div className="lg:w-1/4" data-aos="fade-left">
                <div className="flex flex-col gap-6">
                  <div className="bg-gradient-to-br from-gray-100 via-blue-50 to-white rounded-[30px] p-6 shadow-md border-l-10  border-r-2 border-[#27a03b]  text-center">
                    <span className="text-3xl font-bold text-gray-900">500+</span>
                    <p className="text-sm text-gray-600 font-medium">Products In </p>
                  </div>
                  <div className="bg-gradient-to-br from-gray-100 via-blue-50 to-white rounded-[30px] p-6 shadow-md border-l-10  border-r-2 border-[#27a03b]  text-center">
                    <span className="text-3xl font-bold text-gray-900">98%</span>
                    <p className="text-sm text-gray-600 font-medium">Client Satisfaction</p>
                  </div>
                  <div className="bg-gradient-to-br from-gray-100 via-blue-50 to-white rounded-[30px] p-6 shadow-md border-l-10  border-r-2 border-[#27a03b]  text-center">
                    <span className="text-3xl font-bold text-gray-900">10+</span>
                    <p className="text-sm text-gray-600 font-medium">Years Experience</p>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <ServiceCard
              icon={<TbTruckDelivery />}
              title="Fast Delivery"
              description="Develop comprehensive business strategies aligned with your vision..."
              delay="100"
            />
            <ServiceCard
              icon={<GiReturnArrow />}
              title="Return Policy"
              description="Identify operational inefficiencies and implement targeted improvements..."
              delay="200"
            />
            <ServiceCard
              icon={<HiOutlineCash />}
              title="Cash On Delivery"
              description="Build high-performing teams and effective organizational structures..."
              delay="300"
            />
            <ServiceCard
              icon={<BsGraphUpArrow />}
              title="Market Sell"
              description="Identify and capitalize on new market opportunities through..."
              delay="400"
            />
          </div>
        </div>

      </section>
    </>
  )
}

function ServiceCard({ icon, title, description, delay }) {
  return (
    <div className="h-full" data-aos="fade-up" data-aos-delay={delay}>
      <div className="bg-white rounded-[30px] p-8 h-full transition-transform duration-300 relative shadow-md hover:-translate-y-2 hover:shadow-xl border border-gray-100">
        <div className="w-14 h-14 rounded-lg flex items-center justify-center text-xl mb-6 bg-blue-100 text-[#27a03b] transition-all duration-300 hover:bg-[#27a03b] hover:text-white">
          {icon}
        </div>
        <h3 className="text-lg font-bold mb-4 text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600 leading-relaxed">{description}</p>
      </div>
    </div>

    
  );
}